#ifndef GTINGAME_BITMAP_H
#define GTINGAME_BITMAP_H
extern const unsigned short GTinGame[36000];
#define GTINGAME_WIDTH 240
#define GTINGAME_HEIGHT 150
#endif
BRICK BASKETBALL

This is a version of the classic Brickbreaker game where we want to shoot our basketball well enough to counter all the bricks that UGA has thrown (throwing a brick in basketball is shooting the ball so badly at the rim that it makes a sound like a brick). 

Help Buzz win by using your left and right arrow keys on your computer's keyboard or your left and right D-pad arrows on your gameboy to move the platform and keep shooting the ball. Use the Z button on your computer's keyboard or the A button on your gameboy to move between screens(you will be directed in-game). You can also press the backspace button on you keyboard or the SELECT button on your gameboy to go back to the main screen at all times.

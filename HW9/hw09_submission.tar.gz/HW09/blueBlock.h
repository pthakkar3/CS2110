#ifndef BLUEBLOCK_BITMAP_H
#define BLUEBLOCK_BITMAP_H
extern const unsigned short blueBlock[128];
#define BLUEBLOCK_WIDTH 16
#define BLUEBLOCK_HEIGHT 8
#endif
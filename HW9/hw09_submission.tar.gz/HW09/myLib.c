#include "myLib.h"

unsigned short *videoBuffer = (unsigned short *)0x6000000;

void setPixel(int row, int col, unsigned short color)
{
	videoBuffer[OFFSET(row, col, 240)] = color;
}


void drawRect(int row, int col, int height, int width, unsigned short color)
{
	for(int r = 0; r<height; r++)
	{
		DMA[3].src = &color;
		DMA[3].dst = &videoBuffer[OFFSET(row+r, col, 240)];
		DMA[3].cnt = width | DMA_SOURCE_FIXED | DMA_ON;
	}
}

void delay(int n)
{
	volatile int x = 0;
	for(int i = 0; i < n*10000; i++)
	{
		x = x + 1;
	}
}

void waitForVblank()
{
	while(SCANLINECOUNTER > 160);
	while(SCANLINECOUNTER < 160);
}

void fillScreen(volatile u16 color)
{
	DMA[3].src = &color;
	DMA[3].dst = videoBuffer;
	DMA[3].cnt = 38400 | DMA_ON | DMA_SOURCE_FIXED;
}

void drawImage3(int row, int col, int width, int height, const u16* image)
{
	for (int r = 0; r < height; r++) 
	{
		DMA[3].src = image + (r * width);
		DMA[3].dst = videoBuffer + ((row + r) * 240) + col;
		DMA[3].cnt = width | DMA_ON | DMA_SOURCE_INCREMENT;
	}
}

void replace(int row, int col, int width, int height, const u16* image)
{
	for (int r = 0; r < height; r++) 
	{
		DMA[3].src = image + ((row + r - 10) * 240) + col;
		DMA[3].dst = videoBuffer + ((row + r) * 240) + col;
		DMA[3].cnt = width | DMA_ON;
	}
}

void drawSprite(int r, int c, int width, int height, const u16* image)
{
	for (int j = r; j < height + r; j++)
	{
		for (int i = c; i < width + c; i++)
		{
			if (image[(j - r) * width + (i - c)] != 31775)
			{
				videoBuffer[j * 240 + i] = image[(j - r) * width + (i - c)];
			}
		}
	}
}









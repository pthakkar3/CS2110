#ifndef BASKETBALL_BITMAP_H
#define BASKETBALL_BITMAP_H
extern const unsigned short basketball[100];
#define BASKETBALL_WIDTH 10
#define BASKETBALL_HEIGHT 10
#endif
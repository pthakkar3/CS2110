typedef struct 
{
	int row;
	int col;
	u16 oldBlockPixels[128];
} BLOCK;

typedef struct 
{
	int row;
	int col;
	int rdel;
	int cdel;
	const u16* image;
} PLATFORM;

typedef struct 
{
	int row;
	int col;
	int rdel;
	int cdel;
	const u16* image;	
} BALL;

#define NUMBLOCKS 180

#define DRAW_START_SPLASH drawImage3(0, 0, 240, 160, buzzStart)
#define DRAW_YOU_WIN_SPLASH drawImage3(0, 0, 240, 160, buzzWin)
#define DRAW_GAME_OVER_SPLASH drawImage3(0, 0, 240, 160, gameOver)

void createLevel(unsigned int* blockCounter, BLOCK blocks[NUMBLOCKS], PLATFORM* plat, BALL* ball);

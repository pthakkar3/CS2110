#ifndef BUZZSTART_BITMAP_H
#define BUZZSTART_BITMAP_H
extern const unsigned short buzzStart[38400];
#define BUZZSTART_WIDTH 240
#define BUZZSTART_HEIGHT 160
#endif
#ifndef BLACKBLOCK_BITMAP_H
#define BLACKBLOCK_BITMAP_H
extern const unsigned short blackBlock[128];
#define BLACKBLOCK_WIDTH 16
#define BLACKBLOCK_HEIGHT 8
#endif
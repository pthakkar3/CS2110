#include <stdio.h>
#include <stdlib.h>
#include "myLib.h"
#include "text.h"

#include "game.h"

#include "buzzStart.h"
#include "buzzWin.h"
#include "gameOver.h"
#include "GTinGame.h"

#include "basketball.h"
#include "platform.h"


enum gameState 
{
	START,
	START_NODRAW,
	INGAME,
	INGAME_NODRAW,
	YOU_WIN,
	GAME_OVER,
	GAME_OVER_NODRAW
};

void handlePlatformMove(PLATFORM* plat);
void handleGameState(enum gameState* state, unsigned int* blockCounter, BLOCK blocks[NUMBLOCKS], 		PLATFORM* plat, BALL* ball, unsigned int* score, char scoreBuffer[], const u16* splash);

int main() 
{
	REG_DISPCTL = MODE3 | BG2_ENABLE;
	enum gameState state = START;
	
	PLATFORM plat;
	plat.image = platform;
	
	BALL ball;
	ball.image = basketball;

	BLOCK BLOCKS[NUMBLOCKS];
	
	unsigned int numBlocks = 0;
	unsigned int aPressed = 0;
	unsigned int selectPressed = 0;
	unsigned int score = 0;
	unsigned int highScore = 0;

	char scoreBuffer[sizeof(unsigned int) * 3 + 2];
	char highScoreBuffer[sizeof(unsigned int) * 3 + 2];

	while (1)
	{
		
		switch(state)
		{
			case START: 
			{
				DRAW_START_SPLASH;
				drawString(80, 0, "BRICK", BLACK);
				drawString(90, 0, "BASKETBALL", BLACK);
				drawString(140, 0, "PRESS A TO PLAY", RED);
        			drawString(0, 0, "SCORE:", BLACK);
        			score = 0;
        			sprintf(scoreBuffer, "%d", score);
        			drawString(0, 40, scoreBuffer, BLACK);
        			drawString(0, 140, "HI-SCORE:", BLACK);
        			sprintf(highScoreBuffer, "%d", highScore);
        			drawString(0, 200, highScoreBuffer, BLACK);
				state = START_NODRAW;
			} break;
			
			case START_NODRAW:
			{
				if (KEY_DOWN_NOW(BUTTON_A) && !aPressed) 
				{
					aPressed = 1;
					state = INGAME;
				} else if(!KEY_DOWN_NOW(BUTTON_A))
				{
					aPressed = 0;	
				}
			} break;

			case INGAME:
			{
				createLevel(&numBlocks, BLOCKS, &plat, &ball);
				state = INGAME_NODRAW;
			} break;

			case INGAME_NODRAW: 
			{
				handleGameState(&state, &numBlocks, BLOCKS, &plat, &ball, &score, 						scoreBuffer, GTinGame);
			} break;
	
			case YOU_WIN:
			{
				DRAW_YOU_WIN_SPLASH;
				if (score > highScore) 
				{
					highScore = score;
					sprintf(highScoreBuffer, "%d", highScore);
				}
				drawString(0, 0, "YOU WIN!", BLACK);
				drawString(0, 160, "SCORE:", BLACK);
				sprintf(scoreBuffer, "%d", score);
				drawString(0, 200, scoreBuffer, BLACK);
			} break;

			case GAME_OVER:
			{
				DRAW_GAME_OVER_SPLASH;
				if (score > highScore) 
				{				
					highScore = score;
					sprintf(highScoreBuffer, "%d", highScore);
				}
				drawString(5, 0, "YOU LET THE", BLACK);
				drawString(15, 0, "DAWGS OUT!", BLACK);
				drawString(0, 160, "GAME OVER!", BLACK);
				drawString(25, 160, "A TO RESTART", RED);
				drawString(10, 160, "SCORE:", BLACK);
				sprintf(scoreBuffer, "%d", score);
				drawString(10, 200, scoreBuffer, BLACK);
				score = 0;
				state = GAME_OVER_NODRAW;
			} break;

			case GAME_OVER_NODRAW:
			{
				if (KEY_DOWN_NOW(BUTTON_A) && !aPressed) 
				{
					aPressed = 1;
					state = START;
				} else if (!KEY_DOWN_NOW(BUTTON_A))
				{
					aPressed = 0;
				}
			} break;
		}

		if (KEY_DOWN_NOW(BUTTON_SELECT) && !selectPressed)
		{
			selectPressed = -1;
			state = START;
		} else if (!KEY_DOWN_NOW(BUTTON_SELECT))
		{
			selectPressed = 0;
		}
		waitForVblank();
	}

	return 0;
}


void handleGameState(enum gameState* state, unsigned int* blockCounter, BLOCK blocks[NUMBLOCKS], 		PLATFORM* plat, BALL* ball, unsigned int* score, char scoreBuffer[], const u16* splash)
{
	if(!*blockCounter)
	{
		*state = YOU_WIN;
	}
	
	handlePlatformMove(plat);

	if (plat -> cdel != 0)
	{
		plat -> col += plat -> cdel;
		replace(plat -> row, plat -> col - plat -> cdel, 30, 15, splash);
		drawSprite(plat -> row, plat -> col, 30, 15, platform);
	}

	ball -> row += ball -> rdel;
	ball -> col += ball -> cdel;
	replace(ball -> row - ball -> rdel, ball -> col - ball -> cdel, 10, 8, splash);
	drawSprite(ball -> row, ball -> col, 10, 8, basketball);

	if (ball -> row + 7 >= plat -> row && ball -> row + 7 <= plat -> row + 15)
	{
		if (ball -> col + 6 >= plat -> col && ball -> col <= plat -> col + 26)
		{
			ball -> rdel = -1;
			ball -> cdel = 1 * (plat -> cdel / 2);
		}
	}

	if (ball -> row > 160) 
	{
		*state = GAME_OVER;
	}
	if (ball -> row == 10)
	{
		ball -> rdel = 1;
	}
	if (ball -> col == 0)
	{
		ball -> cdel = 1;
	}
	if (ball -> col == 230)
	{
		ball -> cdel = -1;
	}

	for (int i = 0; i < NUMBLOCKS; i++)
	{
		if (ball -> row == blocks[i].row + 8 
			&& (ball -> col + 10 >= blocks[i].col && ball -> col <= blocks[i].col + 16))
		{
			ball -> rdel = 1;
			*score += 10;
			drawRect(0, 40, 10, 100, WHITE);
			sprintf(scoreBuffer, "%d", *score);
			drawString(0, 40, scoreBuffer, BLACK);
			*blockCounter = *blockCounter - 1;
			replace(blocks[i].row, blocks[i].col, 16, 8, splash);
			blocks[i].row = -100;
			blocks[i].col = -100;
		} else if (ball -> row + 8 == blocks[i].row
			&& (ball -> col + 10 >= blocks[i].col && ball -> col <= blocks[i].col + 16))
		{
			ball -> rdel = 1;
			*score += 10;
			drawRect(0, 40, 10, 100, WHITE);
			sprintf(scoreBuffer, "%d", *score);
			drawString(0, 40, scoreBuffer, BLACK);
			*blockCounter = *blockCounter - 1;
			replace(blocks[i].row, blocks[i].col, 16, 8, splash);
			blocks[i].row = -100;
			blocks[i].col = -100;
		} else if (ball -> row + 8 >= blocks[i].row && ball -> row <= blocks[i].row + 8
			&& ball -> col == blocks[i].col + 16)
		{
			ball -> rdel = 1;
			*score += 10;
			drawRect(0, 40, 10, 100, WHITE);
			sprintf(scoreBuffer, "%d", *score);
			drawString(0, 40, scoreBuffer, BLACK);
			*blockCounter = *blockCounter - 1;
			replace(blocks[i].row, blocks[i].col, 16, 8, splash);
			blocks[i].row = -100;
			blocks[i].col = -100;
		} else if (ball -> row + 8 >= blocks[i].row && ball -> row <= blocks[i].row + 8
			&& ball -> col + 10 == blocks[i].col)
		{
			ball -> rdel = 1;
			*score += 10;
			drawRect(0, 40, 10, 100, WHITE);
			sprintf(scoreBuffer, "%d", *score);
			drawString(0, 40, scoreBuffer, BLACK);
			*blockCounter = *blockCounter - 1;
			replace(blocks[i].row, blocks[i].col, 16, 8, splash);
			blocks[i].row = -100;
			blocks[i].col = -100;
		}
	}
}


void handlePlatformMove(PLATFORM* plat)
{
	if (KEY_DOWN_NOW(BUTTON_LEFT) && !(plat -> col <= 0)) 
	{
		plat -> cdel = -2;
	} else if (KEY_DOWN_NOW(BUTTON_RIGHT) && !(plat -> col >= 210))
	{
		plat -> cdel = 2;
	} else
	{
		plat -> cdel = 0;
	}
}




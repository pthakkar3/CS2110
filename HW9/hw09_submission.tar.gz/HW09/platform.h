#ifndef PLATFORM_BITMAP_H
#define PLATFORM_BITMAP_H
extern const unsigned short platform[450];
#define PLATFORM_WIDTH 30
#define PLATFORM_HEIGHT 15
#endif
#include "myLib.h"
#include "game.h"

#include "buzzStart.h"
#include "buzzWin.h"
#include "gameOver.h"
#include "GTinGame.h"

#include "basketball.h"
#include "platform.h"

#include "blackBlock.h"
#include "blueBlock.h"
#include "goldBlock.h"

#define DRAW_BLACK_BLOCK(r, c) drawImage3(r, c, 16, 8, blackBlock)
#define DRAW_BLUE_BLOCK(r, c) drawImage3(r, c, 16, 8, blueBlock)
#define DRAW_GOLD_BLOCK(r, c) drawImage3(r, c, 16, 8, goldBlock)

#define DRAW_BLACK_BLOCKS(r, c, num) for (int i = c; i < c + 16 * num; i += 16) DRAW_BLACK_BLOCK(r, i)
#define DRAW_BLUE_BLOCKS(r, c, num) for (int i = c; i < c + 16 * num; i += 16) DRAW_BLUE_BLOCK(r, i)
#define DRAW_GOLD_BLOCKS(r, c, num) for (int i = c; i < c + 16 * num; i += 16) DRAW_GOLD_BLOCK(r, i)



void createLevel(unsigned int* blockCounter, BLOCK blocks[NUMBLOCKS], PLATFORM* plat, BALL* ball)
{
	*blockCounter = NUMBLOCKS;
	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 15; j++)
		{
			blocks[(i * 15) + j].row = 10 + (i * 8);
			blocks[(i * 15) + j].col = (j * 16);
		}
	}
	
	//init platform
	plat -> row = 140;
	plat -> col = 105;
	plat -> rdel = 0;
	plat -> cdel = 0;

	//init ball
	ball -> row = 105;
	ball -> col = 110;
	ball -> rdel = 1;
	ball -> cdel = 0;

	//draw inGame screen
	drawImage3(10, 0, 240, 150, GTinGame);

	//draw platform
	drawSprite(plat -> row, plat -> col, 30, 15, platform);

	//draw ball
	drawSprite(ball -> row, ball -> col, 10, 8, basketball);

	DRAW_BLACK_BLOCKS(10, 0, 15);
	DRAW_BLACK_BLOCKS(18, 0, 15);
	DRAW_BLACK_BLOCKS(26, 0, 15);
	DRAW_BLACK_BLOCKS(34, 0, 15);
	DRAW_GOLD_BLOCKS(42, 0, 15);
	DRAW_GOLD_BLOCKS(50, 0, 15);
	DRAW_GOLD_BLOCKS(58, 0, 15);
	DRAW_GOLD_BLOCKS(66, 0, 15);
	DRAW_BLUE_BLOCKS(74, 0, 15);
	DRAW_BLUE_BLOCKS(82, 0, 15);
	DRAW_BLUE_BLOCKS(90, 0, 15);
	DRAW_BLUE_BLOCKS(98, 0, 15);
}

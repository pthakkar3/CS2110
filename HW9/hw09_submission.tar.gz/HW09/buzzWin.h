#ifndef BUZZWIN_BITMAP_H
#define BUZZWIN_BITMAP_H
extern const unsigned short buzzWin[38400];
#define BUZZWIN_WIDTH 240
#define BUZZWIN_HEIGHT 160
#endif